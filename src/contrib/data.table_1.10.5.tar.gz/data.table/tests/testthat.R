if(requireNamespace("testthat", quietly = TRUE)){
    library(testthat)
    library(data.table)
    test_check("data.table")
}

